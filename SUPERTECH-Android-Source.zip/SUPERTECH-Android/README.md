# SUPERTECH Android app

This project packages the supplied SUPERTECH Black & Gold HTML website inside an Android WebView.

## Build an installable APK in GitHub Actions
1. Create a GitHub repository and upload the contents of this folder (keep `.github/workflows/android.yml`).
2. Open the repository's **Actions** tab.
3. Select **Build SUPERTECH Android APK** and press **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `SUPERTECH-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow your browser/file manager to install unknown apps.

The debug APK is signed automatically with Android's debug key and is installable for testing. It is not a Play Store production signing key.

## Release signing
For a production/release APK, create and securely store your own Android keystore, then configure Gradle's `signingConfig` and GitHub Actions secrets. Never commit the keystore or passwords to this repository. Keep the same signing key for every future update; Android will reject updates signed with a different key.

## App details
- Package: `com.supertech.app`
- Minimum Android: Android 6.0 (API 23)
- Internet permission: required for externally hosted website images/links.
- JavaScript and DOM storage: enabled for the existing interactive website.
- Camera/microphone: not requested or automatically granted.

## Local build
Install JDK 17, Android SDK (platform 35 + build tools), and Gradle 8.9, then run:
`gradle assembleDebug`
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Important
This environment does not have Android SDK or Gradle installed, so an APK was not compiled or device-tested here. The included GitHub Actions workflow performs the real cloud build and publishes the installable debug APK as an artifact.
